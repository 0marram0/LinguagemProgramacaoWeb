<?php

require_once(__DIR__ . "/../model/Time.php");

if(isset($_POST["nome"])){
    $nomeTime = $_POST["nome"];
    $formacaoTime = $_POST["formacao"];

    $time = new Time($nomeTime, $formacaoTime);
}
