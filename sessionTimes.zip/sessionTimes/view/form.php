<?php

require_once(__DIR__ . "/../../include/header.php");

?>


<div class="row">
    <div class="col-6">
        <form action="criar.php" method="POST">
        
        <label for="nomeTime">Nome: </label>
        <input type="text" id="nomeTime" name="nome">
        
        <label for="selFormacao">Formação: </label>
        <select name="formacao" id="selFormacao">
            <option value="">----Selecionar Formação----</option>
            <option value="433">4-3-3</option>
            <option value="451">4-2-3-1</option>
            <option value="442">4-4-2</option>
            <option value="352">3-5-2</option>
            <option value="343">3-4-3</option>
            <option value="532">5-3-2</option>
        </select>

        <button type="submit">Enviar</button>
        </form>
    </div>
</div>

<?php

require_once(__DIR__ . "/../include/footer.php");

?>