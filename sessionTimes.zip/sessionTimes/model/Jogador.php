<?php 

class Jogador {
    
    //Atributos
    private $nome;
    private $posicao;

    //GET's & SET's
    public function getNome()
    {
        return $this->nome;
    }

    public function setNome($nome): self
    {
        $this->nome = $nome;

        return $this;
    }

    public function getPosicao()
    {
        return $this->posicao;
    }

    public function setPosicao($posicao): self
    {
        $this->posicao = $posicao;

        return $this;
    }
}