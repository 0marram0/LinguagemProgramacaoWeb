<?php

class Time {

    //Atributos
    private $nome;
    private $formacao;
    private array $jogadores = array();

    //Métodos
    public function __construct($nome, $formacao){
        $this->nome = $nome;
        $this->formacao = $formacao;
    }

    //GET's & SET's

    public function getNome()
    {
        return $this->nome;
    }

    public function setNome($nome): self
    {
        $this->nome = $nome;

        return $this;
    }

    public function getFormacao()
    {
        return $this->formacao;
    }

    public function setFormacao($formacao): self
    {
        $this->formacao = $formacao;

        return $this;
    }

    public function getJogadores(): array
    {
        return $this->jogadores;
    }

    public function setJogadores(array $jogadores): self
    {
        $this->jogadores = $jogadores;

        return $this;
    }
}