<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerador de Times</title>
</head>
<body>
    
    <div class="title">
        <h1>Gerador de Times</h1>
    </div>

